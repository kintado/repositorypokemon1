import { Component } from '@angular/core';

@Component({
  selector: 'chisiamo',
  imports: [],
  templateUrl: './chisiamo.html',
  styleUrl: './chisiamo.css'
})
export class Chisiamo {

}
