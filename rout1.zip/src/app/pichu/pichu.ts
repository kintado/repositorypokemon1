import { Component } from '@angular/core';

@Component({
  selector: 'pichu',
  imports: [],
  templateUrl: './pichu.html',
  styleUrl: './pichu.css'
})
export class Pichu {

}
