import { Component } from '@angular/core';

@Component({
  selector: 'geneeral',
  imports: [],
  templateUrl: './general.html',
  styleUrl: './general.css'
})
export class General {

}
