import { Component } from '@angular/core';

@Component({
  selector: 'charmander',
  imports: [],
  templateUrl: './charmander.html',
  styleUrl: './charmander.css'
})
export class Charmander {

}
