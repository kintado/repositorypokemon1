import { Component } from '@angular/core';

@Component({
  selector: 'bulbasaur',
  imports: [],
  templateUrl: './bulbasaur.html',
  styleUrl: './bulbasaur.css'
})
export class Bulbasaur {

}
