import { Component } from '@angular/core';
import { RouterOutlet,  RouterModule } from '@angular/router';

@Component({
  selector: 'pikachu',
  imports: [RouterOutlet,  RouterModule],
  templateUrl: './pikachu.html',
  styleUrl: './pikachu.css'
})
export class Pikachu {

}
