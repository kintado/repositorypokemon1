import { Component } from '@angular/core';

@Component({
  selector: 'contatti',
  imports: [],
  templateUrl: './contatti.html',
  styleUrl: './contatti.css'
})
export class Contatti {

}
