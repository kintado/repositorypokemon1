import { Component } from '@angular/core';

@Component({
  selector: 'raichu',
  imports: [],
  templateUrl: './raichu.html',
  styleUrl: './raichu.css'
})
export class Raichu {

}
